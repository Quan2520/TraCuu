# Tra cứu dữ liệu từ Google Sheet

## 📦 Cấu trúc
- `index.html`: Giao diện tra cứu dữ liệu Google Sheet
- Sử dụng API từ [sheet.best](https://sheet.best)

## 🚀 Cách sử dụng

1. Tạo Google Sheet và kết nối với sheet.best để lấy API URL
2. API bạn đang dùng:  
   `https://api.sheetbest.com/sheets/b6e0263f-58a9-4f8d-9230-6b1c1b5cc0c0`
3. Mở `index.html` trên trình duyệt hoặc deploy lên GitHub Pages.

## 🌍 Deploy lên GitHub Pages

1. Đăng nhập GitHub
2. Tạo repository mới (ví dụ: `tra-cuu-sheet`)
3. Push source code lên repo
4. Vào repo → Settings → Pages → Chọn nhánh `main` & thư mục `/root`
5. Truy cập trang: `https://<tên-user>.github.io/tra-cuu-sheet/`